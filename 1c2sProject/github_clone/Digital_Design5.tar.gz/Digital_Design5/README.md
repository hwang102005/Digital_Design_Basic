# Digital_Design
Digital Design using Verilog HDL(Anseong Polytechnic University): 2024-2

## Session 1
* Brief History of Semiconductor Fabrication and Process of Semi Custom IC

## Session 2
* Basic Linux Operation needed for IC EDA Solution Operations

## Session 3
* Gate Level Modeling1 (Basic Overview)

## Session 4
* Simulation using Cadence Xcelium simulator

## Session 5
* Makefile and Automation

## Session 6
* Data Flow Modeling and Operators

## Session 7
* Behavioral Modeling (1)

