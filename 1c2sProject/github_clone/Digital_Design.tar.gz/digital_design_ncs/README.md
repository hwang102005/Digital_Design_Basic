# digital_design_ncs
ncs exam
